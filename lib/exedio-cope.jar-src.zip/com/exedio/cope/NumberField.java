/*
 * Copyright (C) 2004-2009  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import com.exedio.cope.search.AverageAggregate;
import com.exedio.cope.search.SumAggregate;

public abstract class NumberField<E extends Number> extends FunctionField<E> implements NumberFunction<E>
{
	private static final long serialVersionUID = 1l;
	
	protected NumberField(final boolean isfinal, final boolean optional, final boolean unique, final Class<E> valueClass, final E defaultConstant)
	{
		super(isfinal, optional, unique, valueClass, defaultConstant);
	}
	
	// convenience methods for conditions and views ---------------------------------

	@Override
	public final BindNumberFunction<E> bind(final Join join)
	{
		return new BindNumberFunction<E>(this, join);
	}
	
	public final PlusLiteralView<E> plus(final E value)
	{
		return new PlusLiteralView<E>(this, value);
	}
	
	public final MultiplyLiteralView<E> multiply(final E value)
	{
		return new MultiplyLiteralView<E>(this, value);
	}
	
	public final PlusView<E> plus(final NumberFunction<E> other)
	{
		return new PlusView<E>(new NumberFunction[]{this, other});
	}

	public final MultiplyView<E> multiply(final NumberFunction<E> other)
	{
		return new MultiplyView<E>(new NumberFunction[]{this, other});
	}

	public final DivideView<E> divide(final NumberFunction<E> other)
	{
		return new DivideView<E>(this, other);
	}

	public final SumAggregate<E> sum()
	{
		return new SumAggregate<E>(this);
	}

	public final AverageAggregate<E> average()
	{
		return new AverageAggregate<E>(this);
	}

	// ------------------- deprecated stuff -------------------
	
	/**
	 * @deprecated renamed to {@link #plus(NumberFunction)}.
	 */
	@Deprecated
	public final PlusView<E> sum(final NumberFunction<E> other)
	{
		return plus(other);
	}

	/**
	 * @deprecated Use {@link #average()} instead
	 */
	@Deprecated
	public final AverageAggregate<E> avg()
	{
		return average();
	}
}
