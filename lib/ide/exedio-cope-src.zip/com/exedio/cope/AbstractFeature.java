/*
 * Copyright (C) 2004-2015  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import static com.exedio.cope.Feature.requireMounted;
import static com.exedio.cope.Intern.intern;
import static java.util.Objects.requireNonNull;

import com.exedio.cope.misc.Computed;
import com.exedio.cope.misc.LocalizationKeys;
import com.exedio.cope.util.CharSet;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.io.Serial;
import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Nonnull;

abstract class AbstractFeature implements Feature
{
	static final AbstractFeature asAbstract(final Feature feature)
	{
		return (AbstractFeature)feature; // all classes implementing Feature must subclass AbstractFeature
	}

	private static final AtomicInteger instantiationOrderSource = new AtomicInteger(Integer.MIN_VALUE);
	final int instantiationOrder = instantiationOrderSource.getAndIncrement();

	static final CharSet NAME_CHAR_SET = new CharSet('-', '-', '0', '9', 'A', 'Z', 'a', 'z');
	private Mount mountIfMounted = null;

	private abstract static class Mount
	{
		final AbstractType<?> type;
		final String name;
		private final AnnotatedElement annotationSource;
		final Pattern pattern;

		Mount(
				final AbstractType<?> type,
				final String name,
				final AnnotatedElement annotationSource,
				final Pattern pattern)
		{
			this.type = requireNonNull(type);
			this.name = intern(requireNonNull(name));
			this.annotationSource = annotationSource;
			this.pattern = pattern;
		}

		boolean isAnnotationPresent(final Class<? extends Annotation> annotationClass)
		{
			return
				annotationSource!=null &&
				annotationSource.isAnnotationPresent(annotationClass);
		}

		<A extends Annotation> A getAnnotation(final Class<A> annotationClass)
		{
			return
				annotationSource!=null
				? annotationSource.getAnnotation(annotationClass)
				: null;
		}

		private List<String> localizationKeysIfInitialized = null;

		@SuppressWarnings("AssignmentOrReturnOfFieldWithMutableType") // result of ListUtil#trimUnmodifiable is unmodifiable
		final List<String> getLocalizationKeys()
		{
			if(localizationKeysIfInitialized!=null)
				return localizationKeysIfInitialized;

			final ArrayList<String> result = new ArrayList<>();
			addLocalizationKeys(result);
			localizationKeysIfInitialized = List.copyOf(result);
			return localizationKeysIfInitialized;
		}

		final void addLocalizationKeys(final ArrayList<String> result)
		{
			final String suffix = '.' + name.replace('-', '.');
			for(final String prefix : type.getLocalizationKeys())
				result.add(prefix + suffix);

			addInnerLocalizationKeys(result);

			final int dashIndex = name.lastIndexOf('-');
			result.add(dashIndex>=0 ? name.substring(dashIndex+1) : name);
		}

		void addInnerLocalizationKeys(final ArrayList<String> result)
		{
			// empty default implementation
		}

		abstract void toString(StringBuilder sb, Type<?> defaultType);
		abstract Serializable serializable();
	}

	private static final class MountType extends Mount
	{
		final Type<?> type;
		final String id;
		final Class<?> innerLocalizationKeysClass;
		final String   innerLocalizationKeysPostfix;

		MountType(
				final Type<?> type,
				final String name,
				final AnnotatedElement annotationSource,
				final Pattern pattern,
				final Class<?> innerLocalizationKeysClass,
				final String   innerLocalizationKeysPostfix)
		{
			super(type, name, annotationSource, pattern);
			this.type = requireNonNull(type);
			this.id =   intern(type.id + '.' + name);
			this.innerLocalizationKeysClass   = innerLocalizationKeysClass;
			this.innerLocalizationKeysPostfix = innerLocalizationKeysPostfix;
		}

		@Override
		boolean isAnnotationPresent(final Class<? extends Annotation> annotationClass)
		{
			if(Computed.class==annotationClass && getAnnotation(annotationClass)!=null)
				return true;

			return super.isAnnotationPresent(annotationClass);
		}

		@Override
		<A extends Annotation> A getAnnotation(final Class<A> annotationClass)
		{
			if(Computed.class==annotationClass)
			{
				final Pattern pattern = type.getPattern();
				if(pattern!=null)
				{
					final A typePatternAnn = pattern.getAnnotation(annotationClass);
					if(typePatternAnn!=null)
						return typePatternAnn;
				}
			}

			return super.getAnnotation(annotationClass);
		}

		@Override
		void addInnerLocalizationKeys(final ArrayList<String> result)
		{
			if(innerLocalizationKeysClass!=null)
			{
				final String suffix = '.' + innerLocalizationKeysPostfix;
				for(final String prefix : LocalizationKeys.get(innerLocalizationKeysClass))
					result.add(prefix + suffix);
			}

			super.addInnerLocalizationKeys(result);
		}

		@Override
		void toString(final StringBuilder sb, final Type<?> defaultType)
		{
			sb.append((defaultType==type) ? name : id);
		}

		@Override
		public String toString()
		{
			return id;
		}

		@Override
		Serializable serializable()
		{
			return new Serialized(this);
		}
	}

	private static final class MountAbstractType extends Mount
	{
		private final String string;
		private final Serializable serializable;

		MountAbstractType(
				final AbstractType<?> type,
				final String name,
				final String string,
				final Serializable serializable,
				final AnnotatedElement annotationSource)
		{
			super(type, name, annotationSource, null);
			this.string = requireNonNull(string);
			this.serializable = requireNonNull(serializable);
		}

		@Override
		void toString(final StringBuilder sb, final Type<?> defaultType)
		{
			sb.append(string);
		}

		@Override
		public String toString()
		{
			return string;
		}

		@Override
		Serializable serializable()
		{
			return serializable;
		}
	}

	/**
	 * Is called in the constructor of the containing type.
	 */
	void mount(
			final Type<?> type,
			final String name,
			final AnnotatedElement annotationSource)
	{
		{
			final int i = NAME_CHAR_SET.indexOfNotContains(name);
			if(i>=0)
				throw new IllegalArgumentException("name >" + name + "< of feature in type " + type + " contains illegal character >" + name.charAt(i) + "< at position " + i);
		}

		if(mountIfMounted!=null)
			throw new IllegalStateException("feature already mounted: " + mountIfMounted);
		mountIfMounted = new MountType(
				type, name, annotationSource, patternUntilMount,
				innerLocalizationKeysClassUntilMount,
				innerLocalizationKeysPostfixUntilMount);

		type.registerMounted(this);

		this.patternUntilMount = null;
		this.innerLocalizationKeysClassUntilMount = null;
		this.innerLocalizationKeysPostfixUntilMount = null;
	}

	@Override
	public final void mount(
			final AbstractType<?> type,
			final String name,
			final String string,
			final Serializable serializable,
			final AnnotatedElement annotationSource)
	{
		requireNonNull(type, "type");
		requireNonNull(name, "name");
		requireNonNull(string, "string");
		requireNonNull(serializable, "serializable");
		if(mountIfMounted!=null)
			throw new IllegalStateException("feature already mounted: " + mountIfMounted);
		mountIfMounted = new MountAbstractType(type, name, string, serializable, annotationSource);
	}

	private Mount mountAny()
	{
		return requireMounted(mountIfMounted);
	}

	private MountType mountType()
	{
		final Mount result = mountAny();
		if(!(result instanceof MountType))
			throw new IllegalStateException(
					"feature not mounted to a type, but to " + result.type.getClass().getName() + ": " + result);
		return (MountType)result;
	}

	final void assertNotMounted()
	{
		if(mountIfMounted!=null)
			throw new RuntimeException("must be called before mounting the feature");
	}

	final boolean isMountedToType()
	{
		return mountIfMounted instanceof MountType;
	}

	@Override
	public AbstractType<?> getAbstractType()
	{
		return mountAny().type;
	}

	@Override
	public Type<?> getType()
	{
		return mountType().type;
	}

	@Override
	public final String getName()
	{
		return mountAny().name;
	}

	@Override
	public final String getID()
	{
		return mountType().id;
	}

	protected final <P extends Item> Type<P> requireParentClass(
			@Nonnull final Class<P> parentClass,
			@Nonnull final String message)
	{
		requireNonNull(parentClass, message);
		final Class<?> typeClass = getType().getJavaClass();
		if(!typeClass.equals(parentClass))
			throw new ClassCastException(
					message + " " +
					"requires " + typeClass.getName() + ", " +
					"but was " + parentClass.getName());
		return getType().as(parentClass);
	}

	@Override
	public final boolean isAnnotationPresent(final Class<? extends Annotation> annotationClass)
	{
		return mountAny().isAnnotationPresent(annotationClass);
	}

	@Override
	public final <A extends Annotation> A getAnnotation(final Class<A> annotationClass)
	{
		return mountAny().getAnnotation(annotationClass);
	}

	@Override
	public final List<String> getLocalizationKeys()
	{
		return mountAny().getLocalizationKeys();
	}

	final String getDeclaredSchemaName()
	{
		final CopeSchemaName annotation =
			getAnnotation(CopeSchemaName.class);
		if(annotation==null)
			return getName();

		final String result = annotation.value();
		if(result.isEmpty())
			throw new IllegalArgumentException("@CopeSchemaName(\"\") for " + getID());
		return result;
	}

	/**
	 * @param defaultType is used by subclasses
	 */
	void toStringNotMounted(final StringBuilder sb, final Type<?> defaultType)
	{
		sb.append(super.toString());
	}

	@Override
	public final String toString()
	{
		final Mount mount = mountIfMounted;
		if(mount!=null)
		{
			return mount.toString();
		}
		else
		{
			final StringBuilder sb = new StringBuilder();
			toStringNotMounted(sb, null);
			return sb.toString();
		}
	}

	@Override
	public final void toString(final StringBuilder sb, final Type<?> defaultType)
	{
		final Mount mount = mountIfMounted;
		if(mount!=null)
			mount.toString(sb, defaultType);
		else
			toStringNotMounted(sb, defaultType);
	}

	// patterns ------------------

	private Pattern patternUntilMount = null;
	private Class<?> innerLocalizationKeysClassUntilMount;
	private String   innerLocalizationKeysPostfixUntilMount;

	final void registerPattern(
			final Pattern pattern,
			final Class<?> innerLocalizationKeysClass,
			final String   innerLocalizationKeysPostfix)
	{
		assertNotMounted();
		requireNonNull(pattern);

		if(patternUntilMount!=null)
			throw new IllegalStateException(
					"feature has already registered pattern " + patternUntilMount +
					" and tried to register a new one: " + pattern);

		patternUntilMount = pattern;
		innerLocalizationKeysClassUntilMount   = innerLocalizationKeysClass;
		innerLocalizationKeysPostfixUntilMount = innerLocalizationKeysPostfix;
	}

	@Override
	public final Pattern getPattern()
	{
		return mountAny().pattern;
	}

	// serialization -------------

	@Serial
	private static final long serialVersionUID = 1l;

	/**
	 * <a href="https://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/output.html#5324">See Spec</a>
	 */
	@Serial
	protected final Object writeReplace() throws ObjectStreamException
	{
		final Mount mount = mountIfMounted;
		if(mount==null)
		{
			if(isSerializableNonMounted())
				return this;
			else
				throw new NotSerializableException(getClass().getName());
		}

		return mount.serializable();
	}

	/**
	 * Block malicious data streams.
	 * @see #writeReplace()
	 */
	@Serial
	private void readObject(final ObjectInputStream ois) throws IOException, ClassNotFoundException
	{
		if(isSerializableNonMounted())
			ois.defaultReadObject();
		else
			throw new InvalidObjectException("required " + Serialized.class);
	}

	/**
	 * Block malicious data streams.
	 * @see #writeReplace()
	 */
	@Serial
	protected final Object readResolve() throws InvalidObjectException
	{
		if(isSerializableNonMounted())
			return this;
		else
			throw new InvalidObjectException("required " + Serialized.class);
	}

	private boolean isSerializableNonMounted()
	{
		return this instanceof View; // TODO something more generic
	}

	private static final class Serialized implements Serializable
	{
		@Serial
		private static final long serialVersionUID = 1l;

		private final Type<?> type;
		private final String name;

		Serialized(final MountType mount)
		{
			this.type = mount.type;
			this.name = mount.name;
		}

		/**
		 * <a href="https://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/input.html#5903">See Spec</a>
		 */
		@Serial
		private Object readResolve() throws InvalidObjectException
		{
			if(type==null)
				throw new InvalidObjectException("type");
			if(name==null)
				throw new InvalidObjectException("name");
			final Feature result = type.getDeclaredFeature(name);
			if(result==null)
				throw new InvalidObjectException("feature does not exist: " + type + '.' + name);
			return result;
		}
	}
}
