/*
 * Copyright (C) 2004-2015  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import static java.util.Objects.requireNonNull;

import com.exedio.cope.CompareFunctionCondition.Operator;
import java.io.Serial;
import java.util.Collection;

public interface Function<E> extends Selectable<E>
{
	/**
	 * Must throw the same {@link UnsupportedGetException} under the same circumstances as
	 * {@link #get(Item)} and {@link #get(FieldValues)}.
	 */
	void requireSupportForGet() throws UnsupportedGetException;

	E get(Item item) throws UnsupportedGetException;

	default E get(final FieldValues item) throws UnsupportedGetException
	{
		// TODO may be we should throw UnsupportedGetException if item.getBackingItem()==null
		return get(requireNonNull(item.getBackingItem(), "backingItem"));
	}

	// convenience methods for conditions and views ---------------------------------

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is null.
	 */
	default IsNullCondition<E> isNull()
	{
		return new IsNullCondition<>(this, false, Float.NaN);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not null.
	 */
	default IsNullCondition<E> isNotNull()
	{
		return new IsNullCondition<>(this, true, Float.NaN);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is equal to the given parameter.
	 * <p>
	 * To be deprecated, use {@link #is(Object)} instead.
	 */
	default Condition equal(final E value)
	{
		return is(value);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is equal to the given parameter.
	 */
	default Condition is(final E value)
	{
		return Cope.is(this, value);
	}

	/**
	 * @deprecated Use {@link Condition#bind(Join)} instead.
	 */
	@Deprecated
	default Condition equal(final Join join, final E value)
	{
		return is(value).bind(join);
	}

	@SuppressWarnings("unchecked") // Possible heap pollution from parameterized vararg type E
	default Condition in(final E... values)
	{
		return CompositeCondition.in(this, values);
	}

	default Condition in(final Collection<? extends E> values)
	{
		return CompositeCondition.in(this, values);
	}

	/**
	 * To be deprecated, use {@link #isNot(Object)} instead.
	 */
	default Condition notEqual(final E value)
	{
		return isNot(value);
	}

	default Condition isNot(final E value)
	{
		return Cope.isNot(this, value);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is less than the given parameter.
	 */
	default CompareCondition<E> less(final E value)
	{
		return new CompareCondition<>(Operator.Less, this, value);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not greater than the given parameter.
	 */
	default CompareCondition<E> lessOrEqual(final E value)
	{
		return new CompareCondition<>(Operator.LessEqual, this, value);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is greater than the given parameter.
	 */
	default CompareCondition<E> greater(final E value)
	{
		return new CompareCondition<>(Operator.Greater, this, value);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not less than the given parameter.
	 */
	default CompareCondition<E> greaterOrEqual(final E value)
	{
		return new CompareCondition<>(Operator.GreaterEqual, this, value);
	}

	/**
	 * Returns a condition, that is equivalent to
	 * <code>{@link #greaterOrEqual(Object) greaterOrEqual}(lowerBound).{@link Condition#and(Condition) and}({@link #lessOrEqual(Object) lessOrEqual}(upperBound))</code>.
	 */
	default Condition between(final E lowerBound, final E upperBound)
	{
		return greaterOrEqual(lowerBound).and(lessOrEqual(upperBound));
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is equal to the value of the {@code right} function.
	 * <p>
	 * To be deprecated, use {@link #is(Function)} instead.
	 */
	@SuppressWarnings("unchecked") // OK: deprecated API
	default CompareFunctionCondition<E> equal(final Function<? extends E> right)
	{
		return (CompareFunctionCondition<E>)is(right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is equal to the value of the {@code right} function.
	 */
	default Condition is(final Function<? extends E> right)
	{
		return CompareFunctionCondition.create(Operator.Equal, this, right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not equal to the value of the {@code right} function.
	 * <p>
	 * To be deprecated, use {@link #isNot(Function)} instead.
	 */
	@SuppressWarnings("unchecked") // OK: deprecated API
	default CompareFunctionCondition<E> notEqual(final Function<? extends E> right)
	{
		return (CompareFunctionCondition<E>)isNot(right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not equal to the value of the {@code right} function.
	 */
	default Condition isNot(final Function<? extends E> right)
	{
		return CompareFunctionCondition.create(Operator.NotEqual, this, right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is less than the value of the {@code right} function.
	 */
	default CompareFunctionCondition<E> less(final Function<? extends E> right)
	{
		return CompareFunctionCondition.create(Operator.Less, this, right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not greater than the value of the {@code right} function.
	 */
	default CompareFunctionCondition<E> lessOrEqual(final Function<? extends E> right)
	{
		return CompareFunctionCondition.create(Operator.LessEqual, this, right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is greater than the value of the {@code right} function.
	 */
	default CompareFunctionCondition<E> greater(final Function<? extends E> right)
	{
		return CompareFunctionCondition.create(Operator.Greater, this, right);
	}

	/**
	 * Returns a condition, that is true for all items,
	 * if and only if the value of this function for that item
	 * is not less than the value of the {@code right} function.
	 */
	default CompareFunctionCondition<E> greaterOrEqual(final Function<? extends E> right)
	{
		return CompareFunctionCondition.create(Operator.GreaterEqual, this, right);
	}


	/**
	 * {@link Class#cast(Object) Casts}
	 * {@code value} to {@link E} before calling
	 * {@link #is(Object)}
	 * @throws ClassCastException if {@code value} is not assignable to {@link E}
	 */
	default Condition isCasted(final Object value)
	{
		return is(getValueClass().cast(value));
	}

	/**
	 * {@link Class#cast(Object) Casts}
	 * {@code value} to {@link E} before calling
	 * {@link #isNot(Object)}
	 * @throws ClassCastException if {@code value} is not assignable to {@link E}
	 */
	default Condition isNotCasted(final Object value)
	{
		return isNot(getValueClass().cast(value));
	}


	default ExtremumAggregate<E> min()
	{
		return new ExtremumAggregate<>(this, true, Float.NaN);
	}

	default ExtremumAggregate<E> max()
	{
		return new ExtremumAggregate<>(this, false, Float.NaN);
	}

	/**
	 * <b>BEWARE:</b>
	 * This aggregate works on MySQL 5.7 or later only.
	 * See <a href="https://dev.mysql.com/doc/refman/5.7/en/miscellaneous-functions.html#function_any-value">ANY_VALUE</a>.
	 */
	default Aggregate<E,E> any()
	{
		return new AnyAggregate<>(this);
	}

	default Aggregate<E,E> distinct()
	{
		return new Distinct<>(this);
	}

	default Count count()
	{
		return new Count(this);
	}

	Function<E> bind(Join join);

	@Serial
	long serialVersionUID = 8575436913882709690L;
}
