/*
 * Copyright (C) 2004-2009  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import java.util.Map;

final class WrittenState extends State
{
	
	private final Row row;
	private long lastUsageMillis;
	
	WrittenState(final Item item, final Row row, final int modificationCount)
	{
		super(item, modificationCount);
		this.row = row;
		lastUsageMillis = System.currentTimeMillis();
	}
	
	WrittenState(final State original)
	{
		super(original.item, original.modificationCount);
		row = original.stealValues();
		if(row==null) throw new RuntimeException(original.getClass().getName());
		lastUsageMillis = System.currentTimeMillis();
	}
	
	@Override
	Object get(FunctionField field)
	{
		return field.get(row, null);
	}

	@Override
	<E> State put(final Transaction transaction, final FunctionField<E> field, final E value)
	{
		return new ModifiedState(transaction, this).put(transaction, field, value);
	}

	@Override
	State write(final Transaction transaction, final Map<BlobColumn, byte[]> blobs)
	{
		if(blobs!=null && !blobs.isEmpty())
			type.getModel().connect().database.store(transaction.getConnection(), this, true, blobs);
		
		return this;
	}

	@Override
	State delete(Transaction transaction)
	{
		return new DeletedState( transaction, this );
	}

	@Override
	Object store(final Column column)
	{
		//throw new RuntimeException();
		// needed for blobs
		return row.get(column);
	}

	@Override
	Row stealValues()
	{
		return new Row(row);
	}

	@Override
	boolean exists()
	{
		return true;
	}
	
	void notifyUsed()
	{
		lastUsageMillis = System.currentTimeMillis();
	}
	
	long getLastUsageMillis()
	{
		return lastUsageMillis;
	}
	
	@Override
	public String toStringWithValues()
	{
		return toString()+row.toString();
	}
}
